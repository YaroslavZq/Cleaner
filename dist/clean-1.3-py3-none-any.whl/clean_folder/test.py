from clean import cleaner

cleaner("/home/yaroslav/Desktop/test1", "/home/yaroslav/Desktop/test1")
